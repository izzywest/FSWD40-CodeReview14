<?php

/* event/details.html.twig */
class __TwigTemplate_354f2cbd5829853d4c91d626d7ed75c0b5b90aebffedd87a00adc34c43c39925 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "event/details.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/details.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 2
        echo "
<a class=\"btn btn-default\" href=\"/\">Back to Events</a>
<a href=\"/event/edit/";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "id", array()), "html", null, true);
        echo "\" class=\"btn btn-default\">Edit</a>
<a href=\"/event/delete/";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "id", array()), "html", null, true);
        echo "\" class=\"btn btn-danger\">Delete</a>
<hr>

<h2 class=\"page-header\">";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventName", array()), "html", null, true);
        echo "</h2>

<ul class=\"list-group\">

    <img class=\"list-group-item\" src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventImg", array()), "html", null, true);
        echo "\" alt=\"event img\" style=\"width: 30%;\">

    <li class=\"list-group-item\"><u>Type:</u><br> ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventType", array()), "html", null, true);
        echo "</li>

    <li class=\"list-group-item\"><u>Date:</u><br> ";
        // line 16
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventDate", array()), "F j, Y, g:i a"), "html", null, true);
        echo " </li>

    <li class=\"list-group-item\"><u>Capacity:</u><br> ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventCapacity", array()), "html", null, true);
        echo "</li>

    <li class=\"list-group-item\"><u>Contact:</u> <br> Mail:
        <a href=\"mailto:";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventMail", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventMail", array()), "html", null, true);
        echo "</a> <br> Phone: <a href=\"tel:+";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventPhone", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventPhone", array()), "html", null, true);
        echo "</a> </li>

    <li class=\"list-group-item\"><u>Address:</u><br> ";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventStreet", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventStreetN", array()), "html", null, true);
        echo ", <br> ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventZip", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventCity", array()), "html", null, true);
        echo "</li>

    <li class=\"list-group-item\"><u>Link:</u><br> <a target=\"_blank\" href=\"http://";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventUrl", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventUrl", array()), "html", null, true);
        echo "</a> </li>

</ul>

<div class=\"container\" style=\"margin-bottom: 50px;\">
    <h4>Description: </h4>
    <p>
        ";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventDesc", array()), "html", null, true);
        echo "
    </p>
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "event/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 32,  112 => 25,  101 => 23,  90 => 21,  84 => 18,  79 => 16,  74 => 14,  69 => 12,  62 => 8,  56 => 5,  52 => 4,  48 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %} {% block body %}

<a class=\"btn btn-default\" href=\"/\">Back to Events</a>
<a href=\"/event/edit/{{event.id}}\" class=\"btn btn-default\">Edit</a>
<a href=\"/event/delete/{{event.id}}\" class=\"btn btn-danger\">Delete</a>
<hr>

<h2 class=\"page-header\">{{event.eventName}}</h2>

<ul class=\"list-group\">

    <img class=\"list-group-item\" src=\"{{event.eventImg}}\" alt=\"event img\" style=\"width: 30%;\">

    <li class=\"list-group-item\"><u>Type:</u><br> {{event.eventType}}</li>

    <li class=\"list-group-item\"><u>Date:</u><br> {{event.eventDate|date('F j, Y, g:i a')}} </li>

    <li class=\"list-group-item\"><u>Capacity:</u><br> {{event.eventCapacity}}</li>

    <li class=\"list-group-item\"><u>Contact:</u> <br> Mail:
        <a href=\"mailto:{{event.eventMail}}\">{{event.eventMail}}</a> <br> Phone: <a href=\"tel:+{{event.eventPhone}}\">{{event.eventPhone}}</a> </li>

    <li class=\"list-group-item\"><u>Address:</u><br> {{event.eventStreet}} {{event.eventStreetN}}, <br> {{event.eventZip}} {{event.eventCity}}</li>

    <li class=\"list-group-item\"><u>Link:</u><br> <a target=\"_blank\" href=\"http://{{event.eventUrl}}\">{{event.eventUrl}}</a> </li>

</ul>

<div class=\"container\" style=\"margin-bottom: 50px;\">
    <h4>Description: </h4>
    <p>
        {{event.eventDesc}}
    </p>
</div>

{% endblock %}", "event/details.html.twig", "/var/www/html/events/app/Resources/views/event/details.html.twig");
    }
}
