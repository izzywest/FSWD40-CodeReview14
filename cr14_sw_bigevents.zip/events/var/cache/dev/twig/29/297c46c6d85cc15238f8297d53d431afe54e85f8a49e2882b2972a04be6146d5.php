<?php

/* event/index.html.twig */
class __TwigTemplate_da9a051fad22fb1520d4309a730c1d8264a3c963dc47d2fb6e8edf678e5c4631 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "event/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 2
        echo "

<h2 class=\"page-header\">Latest events</h2>
<div class=\"row\">

    <table class=\"table table-striped\">
        <div class=\"col-md-4\">
            <thead>
                <tr>
                    <th>Event</th>
                    <th> </th>
                    <th>Date &amp; time</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th></th>
                </tr>
            </thead>
            ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["event"]);
        foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
            // line 20
            echo "            <tbody>
                <tr>
                    <td><a href=\"/event/details/";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo " \">
                        ";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "eventName", array()), "html", null, true);
            echo "</a></td>
                    <td><img src=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "eventImg", array()), "html", null, true);
            echo "\" alt=\"event img\" style=\"height:100px;\"></td>
                    <td>";
            // line 25
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["event"], "eventDate", array()), "F j, Y, g:i a"), "html", null, true);
            echo "</td>
                    <td>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "eventStreet", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "eventStreetN", array()), "html", null, true);
            echo ", <br> ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "eventZip", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "eventCity", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "eventType", array()), "html", null, true);
            echo "</td>
                    <td>
                        <a href=\"/event/details/";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo " \" class=\"btn btn-success \">More</a>
                        <a href=\"/event/edit/";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo " \" class=\"btn btn-default \">Edit</a>
                        <a href=\"/event/delete/";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo " \" class=\"btn btn-danger \">Delete</a>
                    </td>
                </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "            </tbody>
        </div>
    </table>

</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "event/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 35,  114 => 31,  110 => 30,  106 => 29,  101 => 27,  91 => 26,  87 => 25,  83 => 24,  79 => 23,  75 => 22,  71 => 20,  67 => 19,  48 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %} {% block body %}


<h2 class=\"page-header\">Latest events</h2>
<div class=\"row\">

    <table class=\"table table-striped\">
        <div class=\"col-md-4\">
            <thead>
                <tr>
                    <th>Event</th>
                    <th> </th>
                    <th>Date &amp; time</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th></th>
                </tr>
            </thead>
            {% for event in event %}
            <tbody>
                <tr>
                    <td><a href=\"/event/details/{{event.id}} \">
                        {{event.eventName}}</a></td>
                    <td><img src=\"{{event.eventImg}}\" alt=\"event img\" style=\"height:100px;\"></td>
                    <td>{{event.eventDate|date('F j, Y, g:i a')}}</td>
                    <td>{{event.eventStreet}} {{event.eventStreetN}}, <br> {{event.eventZip}} {{event.eventCity}}</td>
                    <td>{{event.eventType}}</td>
                    <td>
                        <a href=\"/event/details/{{event.id}} \" class=\"btn btn-success \">More</a>
                        <a href=\"/event/edit/{{event.id}} \" class=\"btn btn-default \">Edit</a>
                        <a href=\"/event/delete/{{event.id}} \" class=\"btn btn-danger \">Delete</a>
                    </td>
                </tr>
                {% endfor %}
            </tbody>
        </div>
    </table>

</div>

{% endblock %}", "event/index.html.twig", "/var/www/html/events/app/Resources/views/event/index.html.twig");
    }
}
